//Add watch window variables
expRemoveAll
expAdd "fOutput3" getNatural()
