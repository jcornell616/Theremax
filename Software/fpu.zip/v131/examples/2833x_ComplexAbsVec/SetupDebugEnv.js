//Add watch window variables
expRemoveAll
expAdd "x" getNatural()
expAdd "y" getNatural()
