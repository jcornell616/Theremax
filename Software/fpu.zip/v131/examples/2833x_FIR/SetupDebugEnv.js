//Add watch window variables
expRemoveAll
expAdd "firFP" getNatural()

openAnalysisView('Dual Time','C:/TI/controlSUITE/libs/dsp/FPU/v131/examples/2833x_FIR/FIR.graphProp')
