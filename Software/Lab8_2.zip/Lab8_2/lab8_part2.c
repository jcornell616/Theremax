#include <F28x_Project.h>
#include <stdio.h>
#include <math.h>
#include "4511Drivers\GPIO.h"
#include "4511Drivers\AIC23.h"
#include "4511Drivers\InitAIC23.h"
#include "4511Drivers\LCDDriver.h"

//variables and constants
const int16 N = 512;
const float dft_phase = 2*M_PI/((float) N);
const float Fs = 48000;
const float res = 5.035e-5;
const float freq_res = 93.75;

const char max_freq_str[9] = "Max freq=";
const char max_mag_str[8] = "Max mag=";
const char freq_units_str[3] = " Hz";
const char mag_units_str[4] = " dBs";

volatile char buf_sel;
volatile char fin;

volatile int16 ping_buf[N];
#pragma DATA_SECTION(ping_buf, "ramgs0")
volatile int16 pong_buf[N];
#pragma DATA_SECTION(pong_buf, "ramgs1")
volatile float bins[N/2+1];
#pragma DATA_SECTION(bins, "ramgs2")

//function declarations
interrupt void DMA_ISR(void);

void InitDMA(void);
Uint16 DFT(void);
float parabolic_interpolation(Uint16 k);

//main code
int main(void) {

    //initialize DSP
    InitSysCtrl();

    //zero buffers
    for (Uint16 i = 0; i < N; i++) {
        ping_buf[i] = 0.0;
        pong_buf[i] = 0.0;
        bins[i] = 0.0;
    }
    buf_sel = 0;
    fin = 0;

    //initialize interrupt
    InitLEDs();
    InitDMA();
    EALLOW;
    InitMcBSPbDSPMode();
    InitSPIA();
    InitAIC23DSPMode();

    set_LEDs(0);

    //endless loop
    while (1) {
        if (fin) {
            set_LEDs(1);
            Uint16 max_index = DFT();
            set_LEDs(0);
            float max_mag = 10*log10(sqrt(bins[max_index]));
            float max_freq = parabolic_interpolation(max_index); //((float) max_index)*freq_res;

            fin = 0;
        }
    }
}

//function definitions
interrupt void DMA_ISR(void) {
    EALLOW;

    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP7;

    EDIS;

    EALLOW;
    if ((buf_sel) && (!fin)) {
        DmaRegs.CH6.DST_BEG_ADDR_SHADOW = (Uint32)&ping_buf;
        DmaRegs.CH6.DST_ADDR_SHADOW = (Uint32)&ping_buf;
        fin = 1;
        buf_sel = !(buf_sel);
    }
    else if ((!buf_sel) && (!fin)) {
        DmaRegs.CH6.DST_BEG_ADDR_SHADOW = (Uint32)&pong_buf;
        DmaRegs.CH6.DST_ADDR_SHADOW = (Uint32)&pong_buf;
        fin = 1;
        buf_sel = !(buf_sel);
    }
    EDIS;

    StartDMACH6();
}

Uint16 DFT(void) {
    float max_mag = 0;
    float max_freq = 0;
    for (Uint16 k = 0; k < N/2+1; k++) {
        float real = 0.0;
        float imag = 0.0;
        float k_t = (float) k;
        for (Uint16 n = 0; n < N; n++) {
            float n_t = (float) n;
            if (buf_sel) {
                real += ((float)pong_buf[n])*cos(k_t*n_t*dft_phase);
                imag += ((float)pong_buf[n])*sin(k_t*n_t*dft_phase);
            }
            else {
                real += ((float)ping_buf[n])*cos(k_t*n_t*dft_phase);
                imag += ((float)ping_buf[n])*sin(k_t*n_t*dft_phase);
            }
        }
        float mag = real*real + imag*imag;
        if (mag > max_mag) {
            max_freq = k;
            max_mag = mag;
        }
        bins[k] = mag;
    }
    return max_freq;
}

float parabolic_interpolation(Uint16 k) {
    float delta_m;
    if (k == 0) {
        delta_m = (log10(sqrt(bins[k+1]))) / 2*(2*log10(sqrt(bins[k]))-log10(sqrt(bins[k+1])));
    }
    else if (k == N/2) {
        delta_m = (0 - log10(sqrt(bins[k-1]))) / 2*(2*log10(sqrt(bins[k]))-log10(sqrt(bins[k-1])));
    }
    else {
        delta_m = (log10(sqrt(bins[k+1]))-log10(sqrt(bins[k-1]))) / (2*(2*log10(sqrt(bins[k]))-log10(sqrt(bins[k+1]))-log10(sqrt(bins[k-1]))));
    }
    return freq_res*(((float) k) + delta_m);
}

void InitDMA(void) {
    InitPieCtrl();
    InitPieVectTable();

    //pie vector -> stolen from TI code
    EALLOW;  // This is needed to write to EALLOW protected registers
    PieVectTable.DMA_CH6_INT= &DMA_ISR;
    EDIS;    // This is needed to disable write to EALLOW protected registers

    //Initialize DMA -> stolen from TI code
    DMAInitialize();

    // source and destination pointers
    volatile int16 *DMA_CH6_Source = (volatile int16 *)&McbspbRegs.DRR1.all;
    volatile int16 *DMA_CH6_Dest = (volatile int16 *)&ping_buf;

    // configure DMA CH6 -> modified from TI code
    DMACH6AddrConfig(DMA_CH6_Dest,DMA_CH6_Source);
    DMACH6BurstConfig(0,0,0);
    DMACH6TransferConfig(N-1,0,1);
    DMACH6ModeConfig(74,PERINT_ENABLE,ONESHOT_DISABLE,CONT_DISABLE,
                     SYNC_DISABLE,SYNC_SRC,OVRFLOW_DISABLE,SIXTEEN_BIT,
                     CHINT_END,CHINT_ENABLE);


    //something about a bandgap voltage -> stolen from TI code
    EALLOW;
    CpuSysRegs.SECMSEL.bit.PF2SEL = 1;
    EDIS;


    //interrupt enabling
    PieCtrlRegs.PIECTRL.bit.ENPIE = 1;   // Enable the PIE block
    PieCtrlRegs.PIEIER7.bit.INTx6 = 1;   // Enable PIE Group 7, INT 2 (DMA CH2)
    IER |= M_INT7;                         // Enable CPU INT6
    EINT;                                // Enable Global Interrupts

    EnableInterrupts();

    StartDMACH6();      // Start DMA channel -> stolen from TI code

    //
    // Enable interrupts required for this example -> stolen from TI code
    //
   PieCtrlRegs.PIECTRL.bit.ENPIE = 1;   // Enable the PIE block
   PieCtrlRegs.PIEIER7.bit.INTx6 = 1;   // Enable PIE Group 7, INT 2 (DMA CH2)
   IER |= M_INT7;                         // Enable CPU INT6
   EINT;                                // Enable Global Interrupts
}
