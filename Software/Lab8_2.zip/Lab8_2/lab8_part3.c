#include <F28x_Project.h>
#include <stdio.h>
#include <math.h>
#include <FPU.h>
#include "4511Drivers\GPIO.h"
#include "4511Drivers\AIC23.h"
#include "4511Drivers\InitAIC23.h"

#define FFT_SIZE 512    //32, 64, 128, 256, etc.
#define FFT_STAGES 9    //log2(FFT_SIZE)
#define NO_FFTS 1       //number of FFTs to sample & process

//variables and constants
const float32 Fs = 48000;
const float32 res = 5.035e-5;
const float32 freq_res = 93.75;

volatile char buf_sel;
volatile char fin;
volatile Uint16 iter;

#pragma DATA_SECTION(ping_buf, "ramgs0")
int16 ping_buf[FFT_SIZE*NO_FFTS];
#pragma DATA_SECTION(pong_buf, "ramgs1")
int16 pong_buf[FFT_SIZE*NO_FFTS];
#pragma DATA_SECTION(bins, "ramgs2")
float32 bins[FFT_SIZE];
#pragma DATA_SECTION(twiddles, "ramgs3")
float32 twiddles[FFT_SIZE];
#pragma DATA_SECTION(mag_buf, "ramgs4")
float32 mag_buf[FFT_SIZE/2+1];
#pragma DATA_SECTION(samples, "ramgs5")
float32 samples[FFT_SIZE];

RFFT_F32_STRUCT fft;

//function declarations
interrupt void DMA_ISR(void);

void InitDMA(void);
void InitFFT(void);

//main code
int main(void) {

    //initialize DSP
    InitSysCtrl();
    DINT;

    //zero buffers
    for (Uint16 i = 0; i < FFT_SIZE; i++) {
        ping_buf[i] = 0;
        pong_buf[i] = 0;
        samples[i] = 0.0f;
        bins[i] = 0.0f;
        twiddles[i] = 0.0f;
        if (i < (FFT_SIZE/2+1)) {
            mag_buf[i] = 0.0f;
        }
    }
    buf_sel = 0;
    iter = 0;
    fin = 0;

    //initialize functions
    InitLEDs();
    InitFFT();
    InitDMA();
    InitMcBSPbDSPMode();
    InitSPIA();
    InitAIC23DSPMode();

    set_LEDs(0);

    //endless loop
    while (1) {
        if (fin) {
            //convert to float
            if (buf_sel) {
                for (int i = 0; i < FFT_SIZE; i++) {
                    samples[i] = (float32) ping_buf[i];
                }
            }
            else {
                for (int i = 0; i < FFT_SIZE; i++) {
                    samples[i] = (float32) pong_buf[i];
                }
            }
            //calculate FFT
            set_LEDs(1);
            RFFT_f32(&fft);
            set_LEDs(0);
            //calculate magnitude
            RFFT_f32_mag(&fft);
            //calculate max index
            Uint16 max_index = maxidx_SP_RV_2(mag_buf,FFT_SIZE/2+1);
            float32 max_freq = ((float32)max_index)*freq_res;
            float32 max_mag = 10*log10(mag_buf[max_index]);

            fin = 0;
        }
    }
}

//function definitions
interrupt void DMA_ISR(void) {
    EALLOW;

    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP7;

    EDIS;

    EALLOW;
    if ((buf_sel) && (!fin)) {
        DmaRegs.CH6.DST_BEG_ADDR_SHADOW = (Uint32)&ping_buf;
        DmaRegs.CH6.DST_ADDR_SHADOW = (Uint32)&ping_buf;
        fin = 1;
        buf_sel = !(buf_sel);
    }
    else if ((!buf_sel) && (!fin)) {
        DmaRegs.CH6.DST_BEG_ADDR_SHADOW = (Uint32)&pong_buf;
        DmaRegs.CH6.DST_ADDR_SHADOW = (Uint32)&pong_buf;
        fin = 1;
        buf_sel = !(buf_sel);
    }
    EDIS;

    StartDMACH6();
}

void InitDMA(void) {
    InitPieCtrl();
    InitPieVectTable();

    //pie vector -> stolen from TI code
    EALLOW;  // This is needed to write to EALLOW protected registers
    PieVectTable.DMA_CH6_INT= &DMA_ISR;
    EDIS;    // This is needed to disable write to EALLOW protected registers

    //Initialize DMA -> stolen from TI code
    DMAInitialize();

    // source and destination pointers
    volatile int16 *DMA_CH6_Source = (volatile int16 *)&McbspbRegs.DRR1.all;
    volatile int16 *DMA_CH6_Dest = (volatile int16 *)&ping_buf;

    // configure DMA CH6 -> modified from TI code
    DMACH6AddrConfig(DMA_CH6_Dest,DMA_CH6_Source);
    DMACH6BurstConfig(0,0,0);
    DMACH6TransferConfig(FFT_SIZE-1,0,1);
    DMACH6ModeConfig(74,PERINT_ENABLE,ONESHOT_DISABLE,CONT_DISABLE,
                     SYNC_DISABLE,SYNC_SRC,OVRFLOW_DISABLE,SIXTEEN_BIT,
                     CHINT_END,CHINT_ENABLE);


    //something about a bandgap voltage -> stolen from TI code
    EALLOW;
    CpuSysRegs.SECMSEL.bit.PF2SEL = 1;
    EDIS;


    //interrupt enabling
    PieCtrlRegs.PIECTRL.bit.ENPIE = 1;   // Enable the PIE block
    PieCtrlRegs.PIEIER7.bit.INTx6 = 1;   // Enable PIE Group 7, INT 2 (DMA CH2)
    IER |= M_INT7;                         // Enable CPU INT6
    EINT;                                // Enable Global Interrupts

    EnableInterrupts();

    StartDMACH6();      // Start DMA channel -> stolen from TI code

    //
    // Enable interrupts required for this example -> stolen from TI code
    //
   PieCtrlRegs.PIECTRL.bit.ENPIE = 1;   // Enable the PIE block
   PieCtrlRegs.PIEIER7.bit.INTx6 = 1;   // Enable PIE Group 7, INT 2 (DMA CH2)
   IER |= M_INT7;                         // Enable CPU INT6
   EINT;                                // Enable Global Interrupts
}

void InitFFT(void) {
    fft.InBuf = &samples[0];       //Input data buffer
    fft.OutBuf = &bins[0];         //FFT output buffer
    fft.CosSinBuf = &twiddles[0];  //Twiddle factor buffer
    fft.FFTSize = FFT_SIZE;         //FFT length
    fft.FFTStages = FFT_STAGES;     //FFT Stages
    fft.MagBuf = &mag_buf[0];         //Magnitude buffer
    RFFT_f32_sincostable(&fft);     //Initialize Twiddle Buffers
}
