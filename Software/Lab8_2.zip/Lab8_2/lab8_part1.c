#include <F28x_Project.h>
#include <stdio.h>
#include <math.h>
#include "4511Drivers\GPIO.h"
#include "4511Drivers\AIC23.h"
#include "4511Drivers\InitAIC23.h"
#include "4511Drivers\LCDDriver.h"

//variables and constants
const Uint16 N = 512;
const float32 dft_phase = 2*M_PI/((float) N);
const float32 Fs = 48000;
const float32 res = 5.035e-5;
const float32 freq_res = 93.75;

const char max_freq_str[9] = "Max freq=";
const char max_mag_str[8] = "Max mag=";
const char freq_units_str[3] = " Hz";
const char mag_units_str[4] = " dBs";

volatile char buf_sel;
volatile char fin;
volatile Uint16 iter;
volatile float32 mag;

#pragma DATA_SECTION(ping_buf, "ramgs0")
int16 ping_buf[N];
#pragma DATA_SECTION(pong_buf, "ramgs1")
int16 pong_buf[N];
#pragma DATA_SECTION(bins, "ramgs2")
float32 bins[N/2+1];

//function declarations
interrupt void Mcbspb_ISR(void);

Uint16 DFT(void);
void ftoa(float n, char* res, int16 afterpoint);
Uint16 intToStr(int16 x, char str[], Uint16 dig);
void reverse(char* str, Uint16 len);

//main code
int main(void) {

    //initialize DSP
    InitSysCtrl();
    DINT;

    //zero buffers
    for (Uint16 i = 0; i < N; i++) {
        ping_buf[i] = 0.0;
        pong_buf[i] = 0.0;
        bins[i] = 0.0;
    }
    buf_sel = 0;
    iter = 0;
    fin = 0;
    mag = 0;

    //initialize interrupt
    InitLEDs();
    LCD_Init();
    InitMcBSPbDSPMode();
    InitSPIA();
    InitAIC23DSPMode();
    InitMcBSPbIntRX(&Mcbspb_ISR);

    set_LEDs(0);

    //endless loop
    while (1) {
        if (fin) {
            //compute DFT
            set_LEDs(1);
            Uint16 max_index = DFT();
            set_LEDs(0);
            //calculate maximum magnitude and corresponding frequency
            float32 max_mag = 10*log10(sqrt(bins[max_index]));
            float32 max_freq = ((float32)max_index)*freq_res; //parabolic_interpolation(max_index);

            //convert float to string
            char mag_str[8];
//            snprintf(mag_str, sizeof(mag_str), "%g", max_mag);
            ftoa(max_mag, mag_str, 2);

            char freq_str[8];
//            snprintf(freq_str, sizeof(freq_str), "%g", max_freq);
            ftoa(max_freq, freq_str, 0);

            //display values
            LCD_Send_Command(CLEARDISPLAY);
            LCD_String(max_freq_str, 9);
            LCD_String(freq_str, 4);
            LCD_String(freq_units_str, 3);
            LCD_Send_Command(NEWLINE);
            LCD_String(max_mag_str, 8);
            LCD_String(mag_str, 4);
            LCD_String(mag_units_str, 4);

            fin = 0;
        }
    }
}

//function definitions
interrupt void Mcbspb_ISR(void) {
    //retrieve left and right channels
    int16 left = McbspbRegs.DRR2.all;
    int16 right = McbspbRegs.DRR1.all;
    //write to buffers
    if (buf_sel) {
        ping_buf[iter] = left;
    }
    else {
        pong_buf[iter] = left;
    }
    //handle iterator
    iter++;
    if (iter == N) {
        buf_sel = !(buf_sel);
        iter = 0;
        if (!(fin)) {
            fin = 1;
        }
    }
    //write out
    McbspbRegs.DXR2.all = 0;
    McbspbRegs.DXR1.all = 0;
    //acknowledge interrupt
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP6;
}

Uint16 DFT(void) {
    float32 max_mag = 0;
    float32 max_freq = 0;
    for (Uint16 k = 0; k < N/2+1; k++) {
        float32 real = 0.0;
        float32 imag = 0.0;
        float32 k_t = (float32) k;
        for (Uint16 n = 0; n < N; n++) {
            float32 theta = ((float32)n)*k_t*dft_phase;
            float32 temp = cos(theta);
            if (buf_sel) {
                real += ((float32)pong_buf[n])*temp;
                imag += ((float32)pong_buf[n])*sqrt(1-pow(temp,2));
            }
            else {
                real += ((float32)ping_buf[n])*temp;
                imag += ((float32)ping_buf[n])*sqrt(1-pow(temp,2));
            }
        }
        float32 mag = real*real + imag*imag;
        if (mag > max_mag) {
            max_freq = k;
            max_mag = mag;
        }
        bins[k] = mag;
    }
    return max_freq;
}

void reverse(char* str, Uint16 len)
{
    int16 i = 0, j = len - 1, temp;
    while (i < j) {
        temp = str[i];
        str[i] = str[j];
        str[j] = temp;
        i++;
        j--;
    }
}

Uint16 intToStr(int16 x, char str[], Uint16 dig) {
    //convert to string
    Uint16 i = 0;
    while (x) {
        str[i++] = (x % 10) + '0';
        x = x / 10;
    }
    //pad with zeros
    while (i < dig) {
           str[i++] = '0';
    }
    //put string in correct order and append with null terminator
    reverse(str, i);
    str[i] = '\0';
    //return number of digits converted to string
    return i;
}

void ftoa(float n, char* res, int afterpoint)
{
    //integer portion
    int16 ipart = (int16) n;
    //floating point portion
    float fpart = n - (float) ipart;
    //integer portion to string
    Uint16 i = intToStr(ipart, res, 0);
    //floating point portion to string
    if (afterpoint != 0) {
        res[i] = '.';
        fpart = fpart * pow(10, afterpoint);
        intToStr((int16) fpart, res + i + 1, afterpoint);
    }
}
