%Fs = 30K Hz
%Fw = 3K Hz, L = 200 periods 
clear;         %clear all previous variables to begin test
Fs = 30000;     %sampling frequency
Fw = 3000;      %sine frequency
L = 200;        %number of periods
SPP = Fs/Fw;    %samples per period
N = SPP * L;    %total number of samples
for i = 1:N
        swave(i) = sin(2*pi*(i-1)*Fw/Fs);
end
plot(swave(1:100))   %test purposes