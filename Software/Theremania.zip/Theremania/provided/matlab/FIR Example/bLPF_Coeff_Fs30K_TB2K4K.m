%LPF, Fs = 30K, Passband 0 to 2KHz,Transition Band 2K to 4KHz, Stopband 4K to 15K
%Passband ripple = 3 dB, Stopband attenuation = 40 dB
Taps = 19;
FC = [-0.0035 -0.0235 -0.0404 -0.0525 -0.0417 0.0012 0.0732 0.1561 0.2224 0.2478 0.2224 0.1561 0.0732 0.0012 -0.0417 -0.0525 -0.0404 -0.0235 -0.0035]