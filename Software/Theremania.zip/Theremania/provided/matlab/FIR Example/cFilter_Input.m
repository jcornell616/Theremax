for i = 1:Taps
    waveout(i) = 0.0; %Can't compute these outputs due to no data before filter is fully loaded      
end
for i = Taps+1:N
       waveout(i) = 0.0;
    for j = 1:Taps
       filt_sum = swave(i-j)*FC(j);
       waveout(i) = waveout(i) + filt_sum; 
    end    
end
plot(waveout(1:300))   %test purposes
pause
plot(waveout(1:N))