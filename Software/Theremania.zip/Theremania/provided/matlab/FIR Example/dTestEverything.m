%Test several data sets
aSine_Fs30KHz_Fw1000Hz    %1K sine input
pause
bLPF_Coeff_Fs30K_TB2K4K
cFilter_Input
pause

aSine_Fs30KHz_Fw1500Hz    %1.5K sine input
pause
bLPF_Coeff_Fs30K_TB2K4K
cFilter_Input
pause

aSine_Fs30KHz_Fw3000Hz    %3K sine input
pause
bLPF_Coeff_Fs30K_TB2K4K
cFilter_Input
pause

aSine_Fs30KHz_Fw6000Hz    %6K sine input
pause
bLPF_Coeff_Fs30K_TB2K4K
cFilter_Input
pause

