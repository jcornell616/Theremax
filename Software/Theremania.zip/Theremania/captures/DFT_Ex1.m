%File = DFT_Ex1.m
clear;          %clear all previous variables to begin test
close all;      %close all open figures
Fs = 30000;     %sampling frequency
%Fw1 = 500;     %sine1 frequency
Fw1 = 550;      %sine1 frequency
%Fw2 = 5000;    %sine2 frequency
Fw2 = 5500;     %sine2 frequency 
N = 300;        %number of samples
for i = 1:N
    swave1(i) = sin(2*pi*(i-1)*Fw1/Fs);
    swave2(i) = sin(2*pi*(i-1)*Fw2/Fs);
    swave3(i) = (sin(2*pi*(i-1)*Fw1/Fs) + sin(2*pi*(i-1)*Fw2/Fs));
end
                        
%Sine Display 
figure;
subplot(3,1,1);
plot(swave1(1:N));     
title('Original Sines 500 Hz, 5K Hz, Mixed');
subplot(3,1,2);         
plot(swave2(1:N));     
subplot(3,1,3);         
plot(swave3(1:N));     
pause;

%DFT Computation
figure;
subplot(3,1,1);
plot(abs(fft(swave1(1:N))));     
title('Original Sines 500 Hz, 5K Hz, Mixed');
subplot(3,1,2);         
plot(abs(fft(swave2(1:N))));    
subplot(3,1,3);         
plot(abs(fft(swave3(1:N))));    
pause; 
close all;