realVect = 1:512;
imgVect = 1:512;
for K = 1:512
    for n = 1:512
        realVect(K) = cos(-2*pi*(n-1)*(K-1)/512);
        imgVect(K) = sin(-2*pi*(n-1)*(K-1)/512);
    end
end
Ximag
Xreal