%File = DFT_Ex2.m
clear;          %clear all previous variables to begin test
close all;      %close all previous figures

%Creation of Sines
Fs = 28000;     %sampling frequency
Fw = 1000;      %sine frequency
L = 10;         %number of periods
SPP = Fs/Fw;    %samples per period
N = SPP * L;    %total number of samples
for i = 1:N
        swave28(i) = sin(2*pi*(i-1)*Fw/Fs);
end

Fs = 32000;     %sampling frequency
Fw = 1000;      %sine frequency
L = 10;         %number of periods
SPP = Fs/Fw;    %samples per period
N = SPP * L;    %total number of samples
for i = 1:N
        swave32(i) = sin(2*pi*(i-1)*Fw/Fs);
end

Fs = 36000;     %sampling frequency
Fw = 1000;      %sine frequency
L = 10;         %number of periods
SPP = Fs/Fw;    %samples per period
N = SPP * L;    %total number of samples
for i = 1:N
        swave36(i) = sin(2*pi*(i-1)*Fw/Fs);
end

%Display Sines
figure;
subplot(3,1,1);
plot(swave28(1:64))   %test purposes
title('Sine w/28 Samples Per Period, 64 samples shown');
subplot(3,1,2);
plot(swave32(1:64))   %test purposes
title('Sine w/32 Samples Per Period, 64 samples shown');
subplot(3,1,3);
plot(swave36(1:64))   %test purposes
title('Sine w/36 Samples Per Period, 64 sameples shown');

figure;
subplot(3,1,1);
plot(swave28(1:128))   %test purposes
title('Sine w/28 Samples Per Period, 128 samples shown');
subplot(3,1,2);
plot(swave32(1:128))   %test purposes
title('Sine w/32 Samples Per Period, 128 samples shown');
subplot(3,1,3);
plot(swave36(1:128))   %test purposes
title('Sine w/36 Samples Per Period, 128 sameples shown');

figure;
subplot(3,1,1);
plot(swave28(1:256))   %test purposes
title('Sine w/28 Samples Per Period, 256 samples shown');
subplot(3,1,2);
plot(swave32(1:256))   %test purposes
title('Sine w/32 Samples Per Period, 256 samples shown');
subplot(3,1,3);
plot(swave36(1:256))   %test purposes
title('Sine w/36 Samples Per Period, 256 sameples shown');
pause


%DFT Computations for 28 sample Sine with DFT Length (N) = 64
for K = 1:64
    Xreal(K) = 0;
    Ximag(K) = 0;
    for n = 1:64
        Xreal(K) = Xreal(K)+swave28(n)*cos(-2*pi*(n-1)*(K-1)/64);
        Ximag(K) = Ximag(K)+swave28(n)*sin(-2*pi*(n-1)*(K-1)/64);
    end
end

%Magnitude of complex values from DFT(Sine28[1:64]) and FFT(Sine28[1:64] above
for i =1:64
     DFT_Mag_28_64(i) = (Xreal(i)^2 + Ximag(i)^2)^0.5;
end

%Matlab's FFT Computation which we will compare to the DFT mag above
FFT_Mag_28_64 = abs(fft(swave28(1:64)));

%Display N = 64 DFT & N = 64 FFT Mag plots for 28 Sample Sine 
figure;
subplot(2,1,1);
plot(DFT_Mag_28_64(1:64))   %test purposes
title('N = 64 DFT Mag Results for T = 28');
subplot(2,1,2);
plot(FFT_Mag_28_64)   %test purposes
title('N = 64 FFT Mag Results for T = 28');
pause

%Compute the rest of the FFT Mags for all Sines at N = 64, N = 128, N = 256
FFT_Mag_28_128 = abs(fft(swave28(1:128)));
FFT_Mag_28_256 = abs(fft(swave28(1:256)));

FFT_Mag_32_64 = abs(fft(swave32(1:64)));
FFT_Mag_32_128 = abs(fft(swave32(1:128)));
FFT_Mag_32_256 = abs(fft(swave32(1:256)));

FFT_Mag_36_64 = abs(fft(swave36(1:64)));
FFT_Mag_36_128 = abs(fft(swave36(1:128)));
FFT_Mag_36_256 = abs(fft(swave36(1:256)));

%Plot Mag Results for all three Sines at all three N FFT window sizes
figure;
subplot(3,1,1);
plot(FFT_Mag_28_64(1:32))   %plot half mag values since symmetric
title('64 pt. FFT Mags for Sine w/28 Samples Per Period');
subplot(3,1,2);
plot(FFT_Mag_32_64(1:32))   %plot half mag values since symmetric
title('64 pt. FFT Mags for Sine w/32 Samples Per Period');
subplot(3,1,3);
plot(FFT_Mag_36_64(1:32))   %plot half mag values since symmetric
title('64 pt. FFT Mags for Sine w/36 Samples Per Period');

figure;
subplot(3,1,1);
plot(FFT_Mag_28_128(1:64))   %plot half mag values since symmetric
title('128 pt. FFT Mags for Sine w/28 Samples Per Period');
subplot(3,1,2);
plot(FFT_Mag_32_128(1:64))   %plot half mag values since symmetric
title('128 pt. FFT Mags for Sine w/32 Samples Per Period');
subplot(3,1,3);
plot(FFT_Mag_36_128(1:64))   %plot half mag values since symmetric
title('128 pt. FFT Mags for Sine w/36 Samples Per Period');

figure;
subplot(3,1,1);
plot(FFT_Mag_28_256(1:128))   %plot half mag values since symmetric
title('256 pt. FFT Mags for Sine w/28 Samples Per Period');
subplot(3,1,2);
plot(FFT_Mag_32_256(1:128))   %plot half mag values since symmetric
title('256 pt. FFT Mags for Sine w/32 Samples Per Period');
subplot(3,1,3);
plot(FFT_Mag_36_256(1:128))   %plot half mag values since symmetric
title('256 pt. FFT Mags for Sine w/36 Samples Per Period');

pause
close all

