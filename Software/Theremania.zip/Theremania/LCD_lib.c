/*
 * LCD_lib.c
 *
 *  Created on: Oct 6, 2020
 *      Author: Eric
 */
#include <F28x_Project.h>
#include "OneToOneI2CDriver.h"
#include "LCD_lib.h"

char line_num = 0xC0;

void soft_del(int t)
{
    int dummy = 0;
    for(int i = 0; i < t; i++)
    {
        for(int j = 0; j < t; j++)
        {
            //dummy++;
        }
    }
    dummy = 0;
    return;
}

/* write byte to LCD via I2C, write to CMD*/
void write_cmd(char byte)
{
    Uint16 data_vec[6];

    /*write most sig nibble*/
    char data = byte;
    data &= 0xF0; //clear lower bits
    data |= 0b1000; //send data with NC high, E low, R/W low, RS low for CMD
    data_vec[0] = data;

    data = byte;
    data &= 0xF0; //clear lower bits
    data |= 0b1100; //send data with NC high, E high, R/W low, RS low for CMD
    data_vec[1] = data;

    data = byte;
    data &= 0xF0; //clear lower bits
    data |= 0b1000; //send data with NC high, E low, R/W low, RS low for CMD
    data_vec[2] = data;

    /*write least sig nibble*/
    data = byte << 4;
    data &= 0xF0; //clear lower bits
    data |= 0b1000; //send data with NC high, E low, R/W low, RS low for CMD
    data_vec[3] = data;

    data = byte << 4;
    data &= 0xF0; //clear lower bits
    data |= 0b1100; //send data with NC high, E high, R/W low, RS low for CMD
    data_vec[4] = data;

    data = byte << 4;
    data &= 0xF0; //clear lower bits
    data |= 0b1000; //send data with NC high, E low, R/W low, RS low for CMD
    data_vec[5] = data;

    I2C_O2O_Master_Init(LCD_ADDR, 200, 100);//init slave address for 100 kHz I2C, 200 MHz DSP clk
    I2C_O2O_SendBytes(data_vec, 6);//send out 6 bytes of I2C data to write 1 byte of LCD command data
    return;
}

/* write byte to LCD via I2C, write to DATA*/
void write_data(char byte)
{
    Uint16 data_vec[6];

    /*write most sig nibble*/
    char data = byte;
    data &= 0xF0; //clear lower bits
    data |= 0b1001; //send data with NC high, E low, R/W low, RS high for DATA
    data_vec[0] = data;

    data = byte;
    data &= 0xF0; //clear lower bits
    data |= 0b1101; //send data with NC high, E high, R/W low, RS high for DATA
    data_vec[1] = data;

    data = byte;
    data &= 0xF0; //clear lower bits
    data |= 0b1001; //send data with NC high, E low, R/W low, RS high for DATA
    data_vec[2] = data;

    /*write least sig nibble*/
    data = byte << 4;
    data &= 0xF0; //clear lower bits
    data |= 0b1001; //send data with NC high, E low, R/W low, RS high for DATA
    data_vec[3] = data;

    data = byte << 4;
    data &= 0xF0; //clear lower bits
    data |= 0b1101; //send data with NC high, E high, R/W low, RS high for DATA
    data_vec[4] = data;

    data = byte << 4;
    data &= 0xF0; //clear lower bits
    data |= 0b1001; //send data with NC high, E low, R/W low, RS high for DATA
    data_vec[5] = data;

    I2C_O2O_Master_Init(LCD_ADDR, 200, 10);//init slave address for 10 kHz I2C, 200 MHz DSP clk
    I2C_O2O_SendBytes(data_vec, 6);//send out 6 bytes of I2C data to write 1 byte of LCD data
    return;
}

void write_string(char* string)
{
    for(int i = 0; string[i] != '\0'; i++)
    {
        write_data(string[i]);
        soft_del(10e2);
    }
    return;
}

void init_LCD()
{
    write_cmd(0x33);
    DELAY_US(100);

    write_cmd(0x32);
    soft_del(10e2);

    write_cmd(0x28);
    soft_del(10e2);

    write_cmd(0x0F);
    soft_del(10e2);

    write_cmd(0x01);
    soft_del(10e2);
}

void tgl_line()
{
    if(line_num == 0xC0)
    {
        write_cmd(line_num);
        line_num = 0;
    }
    else
    {
        write_cmd(line_num);
        line_num = 0xC0;
    }
}

void clr_LCD()
{
    write_cmd(0x01);
}

