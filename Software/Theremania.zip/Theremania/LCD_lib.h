/*LCD library*/

#define LCD_ADDR 0x27

void soft_del(int);
void write_cmd(char);
void write_data(char);
void write_string(char*);
void init_LCD();
void tgl_line();
void clr_LCD();
