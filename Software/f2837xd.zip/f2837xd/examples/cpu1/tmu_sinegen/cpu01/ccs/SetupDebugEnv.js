// Add watch window variables and graphs
expRemoveAll
expAdd("pass",getNatural())
expAdd("fail",getNatural())
expAdd("timeRTS",getFloat())
expAdd("timeTMU",getFloat())
expAdd("maxError",getFloat())
openAnalysisView('Dual Time','C:/Users/a0272561/Repositories2/cs30_controlsuite/device_support/f28x7x/F28X7x_examples_Cpu1/tmu_sinegen/cpu01/ccs/tmu_vs_rts.graphProp')