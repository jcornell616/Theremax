//Add Watch window Variables
expRemoveAll
expAdd "sdata" getNatural()
expAdd "rdata" getNatural()
expAdd "rdata_point" getNatural()