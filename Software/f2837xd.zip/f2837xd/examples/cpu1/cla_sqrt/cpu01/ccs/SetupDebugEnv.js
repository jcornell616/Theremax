//Add watch window variables
expRemoveAll
expAdd("fail",getNatural())
expAdd("pass",getNatural())
expAdd("fVal",getNatural())
expAdd("fResult",getNatural())



