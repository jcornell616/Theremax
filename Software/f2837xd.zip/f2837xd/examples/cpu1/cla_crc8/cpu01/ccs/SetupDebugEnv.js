// Add watch window variables and graphs
expRemoveAll
expAdd("crc8_msg1", getHex())
expAdd("crc8_msg2", getHex())
expAdd("crc8_msg3", getHex())
expAdd("crc8_msg4", getHex())
expAdd("pass", getNatural())
expAdd("fail", getNatural())