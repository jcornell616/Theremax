//Add Watch window Variables
expRemoveAll()
expAdd ("dacval")