//Add Watch window Variables
expRemoveAll
expAdd "sdata1" getNatural()
expAdd "sdata2" getNatural()
expAdd "rdata1" getNatural()
expAdd "rdata2" getNatural()
expAdd "rdata1_point" getNatural()
expAdd "rdata2_point" getNatural()