//AddWatchWindowVars_Lab4.js
expRemoveAll
expAdd ("InputPeriodInc");
expAdd ("EPwm1Regs.DBRED");
expAdd ("EPwm1Regs.DBREDHR.bit.DBREDHR");
expAdd ("EPwm1Regs.DBFED");
expAdd ("EPwm1Regs.DBFEDHR.bit.DBFEDHR");
expAdd ("EPwm2Regs.DBRED");
expAdd ("EPwm2Regs.DBREDHR.bit.DBREDHR");
expAdd ("EPwm2Regs.DBFED");
expAdd ("EPwm2Regs.DBFEDHR.bit.DBFEDHR");



