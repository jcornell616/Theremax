//Add watch window variables
expRemoveAll
expAdd("pass",getNatural())
expAdd("fail",getNatural())
expAdd("out",getNatural())
expAdd("gold_out",getNatural())



