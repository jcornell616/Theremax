//Add Watch window Variables
expRemoveAll()
expAdd ("waveformGain")
expAdd ("waveformOffset")
expAdd ("samplingFreq_hz")
expAdd ("tableStep")

