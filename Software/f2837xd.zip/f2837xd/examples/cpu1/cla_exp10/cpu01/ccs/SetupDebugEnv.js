//Add watch window variables
expRemoveAll
expAdd("pass",getNatural())
expAdd("fail",getNatural())
expAdd("Val",getNatural())
expAdd (ExpRes",getNatural())
