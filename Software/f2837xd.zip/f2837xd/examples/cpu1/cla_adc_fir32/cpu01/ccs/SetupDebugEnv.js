//Add watch window variables
expRemoveAll
expAdd("X",getNatural())
expAdd("voltFilt",getNatural())
