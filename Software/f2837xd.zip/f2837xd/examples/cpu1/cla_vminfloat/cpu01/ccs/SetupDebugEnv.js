//Add watch window variables
expRemoveAll
expAdd("fail",getNatural())
expAdd("pass",getNatural())
expAdd ("vector1",getNatural())
expAdd ("vector2",getNatural())
expAdd ("vector3",getNatural())
expAdd ("min1",getNatural())
expAdd ("index1",getNatural())
expAdd ("min2",getNatural())
expAdd ("index2",getNatural())
expAdd ("min3",getNatural())
expAdd ("index3",getNatural())
